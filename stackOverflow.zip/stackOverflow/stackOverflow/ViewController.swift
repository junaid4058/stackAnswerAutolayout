//
//  ViewController.swift
//  stackOverflow
//
//  Created by Junaid's Mac Mini  on 5/21/17.
//  Copyright © 2017 Cuet. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!

    @IBAction func makeAnimation(_ sender: Any) {
        
        let customView = UIView(frame: CGRect(x: 10, y: 10, width: 100, height: 100))
        
        customView.backgroundColor = UIColor.blue
        customView.layer.cornerRadius = 25
        customView.layer.borderWidth = 8
        customView.layer.borderColor = UIColor.red.cgColor
        
        self.view.addSubview(customView)
        
        UIView.animate(withDuration: 4, animations: {
            
           customView.transform =  customView.transform.translatedBy(x: 40, y: 60)
           //customView.transform = customView.transform.rotated(by: CGFloat.pi/2)
           //customView.transform = customView.transform.scaledBy(x: 0, y: 0.5)
            
        })
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.

        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func weight() {
        let weightBMI = 100;
        switch weightBMI {
        case Int.min..<20:
            print("low weight")
        case 20..<26:
            print("low normal")
        default:
            print("over weight")

        }
    }


}

